package com.spectrumx.pckontrolle
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}

@Composable fun App(){
 val scope=rememberCoroutineScope(); var address by remember{mutableStateOf("http://192.168.178.100:8765")}
 var status by remember{mutableStateOf("Nicht verbunden")}; var busy by remember{mutableStateOf(false)}
 fun cmd(path:String){busy=true;scope.launch(Dispatchers.IO){val r=try{
  val c=URL(address.trimEnd('/')+path).openConnection() as HttpURLConnection
  c.requestMethod="POST";c.connectTimeout=2500;c.readTimeout=2500
  val x=c.responseCode;c.disconnect();if(x in 200..299)"Befehl ausgeführt" else "Fehler: HTTP $x"
 }catch(_:Exception){"Nicht erreichbar"};launch(Dispatchers.Main){status=r;busy=false}}}
 MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFB56CFF),background=Color(0xFF07040D),surface=Color(0xFF110B1B))){
  Surface(Modifier.fillMaxSize(),color=Color(0xFF07040D)){Column(Modifier.fillMaxSize().padding(18.dp)){
   Text("PC KONTROLLE",style=MaterialTheme.typography.headlineMedium)
   Text("Dein Handy → dein Windows-PC",color=Color(0xFFBFA9D0))
   Spacer(Modifier.height(18.dp))
   OutlinedTextField(address,{address=it},label={Text("PC-Adresse")},singleLine=true,modifier=Modifier.fillMaxWidth())
   Spacer(Modifier.height(8.dp));Text(status,color=Color(0xFFD6B7FF));Spacer(Modifier.height(14.dp))
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Btn("🔒 Sperren"){cmd("/api/power/lock")};Btn("⏻ Neustart"){cmd("/api/power/restart")}}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Btn("⏾ Schlafen"){cmd("/api/power/sleep")};Btn("⚠ Ausschalten"){cmd("/api/power/shutdown")}}
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Btn("🔊 Lauter"){cmd("/api/media/volume/up")};Btn("🔉 Leiser"){cmd("/api/media/volume/down")};Btn("▶ Play"){cmd("/api/media/playpause")}}
   if(busy){Spacer(Modifier.height(12.dp));CircularProgressIndicator()}
  }
 }}}
@Composable fun RowScope.Btn(t:String,onClick:()->Unit){Button(onClick=onClick,modifier=Modifier.weight(1f).height(54.dp),shape=RoundedCornerShape(16.dp)){Text(t)}}
