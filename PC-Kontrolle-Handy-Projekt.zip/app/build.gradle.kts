plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace="com.spectrumx.pckontrolle"; compileSdk=35
 defaultConfig { applicationId="com.spectrumx.pckontrolle"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.16.0")
 implementation("androidx.activity:activity-compose:1.10.1")
 implementation(platform("androidx.compose:compose-bom:2025.04.01"))
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.0")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}